import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sidebar',
  standalone: false,
  
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.css'
})
export class SidebarComponent {
  constructor(private router: Router, private authService: AuthService) {}
  user: any = {};  
  userImageUrl: string = 'static/uploads/default-profile.png';

  ngOnInit(): void {
    this.getUserData();
  }

  getUserData(): void {
    this.authService.getUserData().subscribe(
      (data) => {
        this.user = data;
        console.log(' Usuario logueado:', this.user);
      },
      (error) => console.error(' Error obteniendo datos del usuario:', error)
    );
  }
  navigateTo(route: string): void {
    this.router.navigate([`/${route}`]);
  }

  goToProfile(): void {
    this.router.navigate(['/profile']);
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}